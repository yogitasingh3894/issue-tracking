import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panel-box',
  templateUrl: './panel-box.component.html',
  styleUrls: ['./panel-box.component.css']
})
export class PanelBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
